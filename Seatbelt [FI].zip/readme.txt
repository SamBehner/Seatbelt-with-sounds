Tekij�: TehRamsus

Lis�� seuraavat lainit serverin k�ynnistys tiedostoon:
 start InteractSoundS
 start seatbelt